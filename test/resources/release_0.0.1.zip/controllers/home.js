/**
 * Prelaunch Home
 */
var path = require('path');

var TEMPLATE_PATH = path.join(__dirname, '../views/layout');

module.exports = {
	path: '/',
	method: 'all',
	description: 'Homepage',
	fn: function (req, res, next) {
		var template = {
			layout: TEMPLATE_PATH,
			title: 'Example Page'
		};
		res.render('home', template);
	}
}
