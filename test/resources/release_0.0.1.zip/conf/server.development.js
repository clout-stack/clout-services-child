/**
 * Development Application Configuration
 */
module.exports = {
	http: {
		port: 8080
	}
};