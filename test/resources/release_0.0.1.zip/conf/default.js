/**
 * Default Application Configuration
 */
module.exports = {
	session: {
		secret: '<SESSION_SECRET>'
	}
};