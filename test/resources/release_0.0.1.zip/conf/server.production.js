/**
 * Production Application Configuration
 */
module.exports = {
	session: {
		secret: '<SESSION_SECRET_PROD>'
	}
};